package dominio;

public class GameConfig {

    private static int numPlayers = 1;  
    private static String colorP1 = "vainilla";
    private static String colorP2 = "vainilla";

    public static void setPlayers(int p) { numPlayers = p; }
    public static int getPlayers() { return numPlayers; }

    public static void setColorP1(String c) { colorP1 = c; }
    public static String getColorP1() { return colorP1; }

    public static void setColorP2(String c) { colorP2 = c; }
    public static String getColorP2() { return colorP2; }
}
