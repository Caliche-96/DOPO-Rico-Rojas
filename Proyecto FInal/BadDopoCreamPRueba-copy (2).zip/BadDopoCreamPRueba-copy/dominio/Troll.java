package dominio;

/**
 * Troll: se mueve en línea recta según su dirección.
 * Al chocar con obstáculo o borde gira a la derecha (giro horario).
 * No rompe bloques ni persigue.
 */
public class Troll extends Enemy {
    private Direccion direccion;

    public Troll(int x, int y, Direccion dir) {
        super(x, y);
        this.direccion = dir;
    }

    @Override
    public void mover(int dx, int dy) {
        
        this.x += dx;
        this.y += dy;
    }

    public Direccion getDireccion() { return direccion; }
    public void setDireccion(Direccion d) { this.direccion = d; }

    public void avanzar(GameBoard board) {
        int nx = x + direccion.dx();
        int ny = y + direccion.dy();
        if (!board.esPosicionValida(nx, ny) || board.getCelda(nx, ny).tieneBloqueNoTransitable()) {
            // gira a la derecha
            direccion = direccion.girarDerecha();
        } else {
            this.x = nx;
            this.y = ny;
        }
    }
}
