package dominio;

import java.util.List;

/**
 * Nivel: encapsula el GameBoard y acciones de alto nivel.
 */
public class Nivel {
    private GameBoard board;

    public Nivel(GameBoard board) {
        this.board = board;
    }

    public GameBoard getBoard() { return board; }

    /**
     * Actualiza el estado: mueve enemigos y verifica colisiones (player/enemy).
     * Devuelve:
     *  0 = todo bien
     *  1 = jugador muerto por enemigo (reiniciar nivel)
     *  2 = nivel completado (todas las frutas)
     */
    public int actualizar() {

        board.actualizarEnemigos();
    
        Player p1 = board.getPlayer();
        Player p2 = board.getPlayer2();
    
        // Revisar colisión con P1
        if (p1 != null) {
            for (Enemy e : board.getEnemigos()) {
                if (e.getX() == p1.getX() && e.getY() == p1.getY()) {
                    return 1; // pierde
                }
            }
        }
    
        // Revisar colisión con P2 si existe
        if (p2 != null) {
            for (Enemy e : board.getEnemigos()) {
                if (e.getX() == p2.getX() && e.getY() == p2.getY()) {
                    return 1;
                }
            }
        }
    
        // Ganó
        if (board.todosFrutosRecogidos()) return 2;
    
        return 0;
    }

}
