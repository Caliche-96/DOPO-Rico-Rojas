package dominio;

public abstract class Fruit extends Entidad {
    protected int puntos;
    protected String spriteName;

    public Fruit(int x, int y, int puntos, String spriteName) {
        super(x, y);
        this.puntos = puntos;
        this.spriteName = spriteName;
    }

    @Override
    public void mover(int dx, int dy) {
        // frutas normalmente estáticas: no hacer nada
    }

    public int getPuntos() { return puntos; }
    public String getSpriteName() { return spriteName; }

    public abstract void recolectar(Player p);
}
