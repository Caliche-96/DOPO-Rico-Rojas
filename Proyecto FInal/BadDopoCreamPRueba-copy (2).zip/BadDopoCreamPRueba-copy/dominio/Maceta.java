package dominio;

/**
 * Maceta: persigue al jugador más cercano.
 * No rompe bloques y se mueve 1 casilla por actualización.
 */
public class Maceta extends Enemy {

    public Maceta(int x, int y) {
        super(x, y);
    }

    @Override
    public void mover(int dx, int dy) {
        // movimiento directo sin lógica adicional
        this.x += dx;
        this.y += dy;
    }

    /**
     * Calcula hacia qué dirección moverse para acercarse al jugador más cercano.
     */
    public void avanzar(GameBoard board) {

        Player objetivo = obtenerPlayerMasCercano(board);
        if (objetivo == null) return;

        int dx = 0;
        int dy = 0;

        // Elegir dirección más corta en X
        if (objetivo.getX() < this.x) dx = -1;
        else if (objetivo.getX() > this.x) dx = 1;

        // Elegir dirección más corta en Y
        if (objetivo.getY() < this.y) dy = -1;
        else if (objetivo.getY() > this.y) dy = 1;

        // Intentar mover en X primero (si se mueve más horizontalmente)
        if (Math.abs(objetivo.getX() - this.x) >= Math.abs(objetivo.getY() - this.y)) {
            if (intentarMover(board, dx, 0)) return;
            intentarMover(board, 0, dy);
        }
        // Intentar mover en Y primero
        else {
            if (intentarMover(board, 0, dy)) return;
            intentarMover(board, dx, 0);
        }
    }

    /**
     * Intenta mover la maceta. Solo se mueve si la celda destino es válida y transitable.
     */
    private boolean intentarMover(GameBoard board, int dx, int dy) {
        int nx = this.x + dx;
        int ny = this.y + dy;

        if (!board.esPosicionValida(nx, ny)) return false;

        Celda c = board.getCelda(nx, ny);

        // NO pasa si hay bloque (indestructible o hielo)
        if (c.getBloque() != null) return false;

       

        // mover
        this.x = nx;
        this.y = ny;

        return true;
    }

    /**
     * Obtiene el jugador más cercano considerando player1 y player2.
     */
    private Player obtenerPlayerMasCercano(GameBoard board) {
        Player p1 = board.getPlayer();
        Player p2 = board.getPlayer2();

        if (p1 == null && p2 == null) return null;
        if (p1 != null && p2 == null) return p1;
        if (p1 == null) return p2;

        // distancia Manhattan
        int d1 = Math.abs(p1.getX() - this.x) + Math.abs(p1.getY() - this.y);
        int d2 = Math.abs(p2.getX() - this.x) + Math.abs(p2.getY() - this.y);

        return (d1 <= d2) ? p1 : p2;
    }
}
