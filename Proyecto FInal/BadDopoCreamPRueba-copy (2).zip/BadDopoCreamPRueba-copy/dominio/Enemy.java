package dominio;

public abstract class Enemy extends Entidad {
    public Enemy(int x, int y) { super(x, y); }
    @Override
    public abstract void mover(int dx, int dy);
}
