package dominio;

public class Celda {
    private Bloque bloque;      // puede ser null
    private Entidad entidad;    // puede ser null
    private Fruit fruit;        // fruta (también podría ser entidad, pero la separamos)

    public Celda() {
        this.bloque = null;
        this.entidad = null;
        this.fruit = null;
    }

    public Bloque getBloque() { return bloque; }
    public void setBloque(Bloque b) { this.bloque = b; }

    public Entidad getEntidad() { return entidad; }
    public void setEntidad(Entidad e) { this.entidad = e; }

    public Fruit getFruit() { return fruit; }
    public void setFruit(Fruit f) { this.fruit = f; }

    public boolean estaOcupadaPorEntidad() { return entidad != null; }

    public boolean tieneBloqueNoTransitable() {
        return bloque != null && !bloque.esTransitable();
    }
}
