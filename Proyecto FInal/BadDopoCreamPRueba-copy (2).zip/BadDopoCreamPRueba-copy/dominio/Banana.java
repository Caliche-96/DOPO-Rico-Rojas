package dominio;

public class Banana extends Fruit {
    public Banana(int x, int y, String spriteName) {
        super(x, y, 100, spriteName); // 100 puntos
    }

    @Override
    public void recolectar(Player p) {
        p.addPuntos(puntos);
        // el manejo de eliminar la fruta del tablero lo hace Nivel/GameBoard
    }
}
