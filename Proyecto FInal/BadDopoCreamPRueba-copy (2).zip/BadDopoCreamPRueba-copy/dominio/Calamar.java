package dominio;

/**
 * Calamar: persigue al jugador más cercano.
 * Si encuentra un IceBlock en su camino, se detiene para romperlo
 * y en el siguiente tick continúa avanzando.
 * No rompe indestructibles.
 */
public class Calamar extends Enemy {

    public Calamar(int x, int y) {
        super(x, y);
    }

    @Override
    public void mover(int dx, int dy) {
        // movimiento directo sin lógica adicional
        this.x += dx;
        this.y += dy;
    }

    
    public void avanzar(GameBoard board) {
    
        Player objetivo = obtenerPlayerMasCercano(board);
        if (objetivo == null) return;
    
        int dx = 0;
        int dy = 0;
    
        // Direccion hacia el jugador
        if (objetivo.getX() < this.x) dx = -1;
        else if (objetivo.getX() > this.x) dx = 1;
    
        if (objetivo.getY() < this.y) dy = -1;
        else if (objetivo.getY() > this.y) dy = 1;
    
        // Intento de movimiento prioritario según distancia
        boolean moverEnXPrimero =
                Math.abs(objetivo.getX() - this.x) >= Math.abs(objetivo.getY() - this.y);
    
        // ===========================
        // CHEQUEAR HIELO
        // ===========================
        int nx1 = this.x + (moverEnXPrimero ? dx : 0);
        int ny1 = this.y + (moverEnXPrimero ? 0 : dy);
    
        int nx2 = this.x + (moverEnXPrimero ? 0 : dx);
        int ny2 = this.y + (moverEnXPrimero ? dy : 0);
    
        // Primera dirección a intentar
        if (board.esPosicionValida(nx1, ny1)) {
            Celda c = board.getCelda(nx1, ny1);
            if (c.getBloque() instanceof IceBlock) {
                // Romper solo UN hielo
                board.removerBloque(nx1, ny1);
                return; // Turno termina aquí
            }
        }
    
        // Segunda dirección a intentar
        if (board.esPosicionValida(nx2, ny2)) {
            Celda c = board.getCelda(nx2, ny2);
            if (c.getBloque() instanceof IceBlock) {
                board.removerBloque(nx2, ny2);
                return;
            }
        }
    
        
        // SI NO HAY HIELO MOVER NORMAL
        
    
        // X primero
        if (moverEnXPrimero) {
            if (intentarMover(board, dx, 0)) return;
            intentarMover(board, 0, dy);
        }
        // Y primero
        else {
            if (intentarMover(board, 0, dy)) return;
            intentarMover(board, dx, 0);
        }
    }


    /**
     * Intenta mover el calamar. Solo se mueve si la celda destino es válida y transitable.
     */
    private boolean intentarMover(GameBoard board, int dx, int dy) {
        int nx = this.x + dx;
        int ny = this.y + dy;

        if (!board.esPosicionValida(nx, ny)) return false;

        Celda c = board.getCelda(nx, ny);

        // NO pasa si hay bloque (indestructible o hielo)
        if (c.getBloque() != null) return false;

       

        // mover
        this.x = nx;
        this.y = ny;

        return true;
    }

    /**
     * Obtiene el jugador más cercano considerando player1 y player2.
     */
    private Player obtenerPlayerMasCercano(GameBoard board) {
        Player p1 = board.getPlayer();
        Player p2 = board.getPlayer2();

        if (p1 == null && p2 == null) return null;
        if (p1 != null && p2 == null) return p1;
        if (p1 == null) return p2;

        // distancia Manhattan
        int d1 = Math.abs(p1.getX() - this.x) + Math.abs(p1.getY() - this.y);
        int d2 = Math.abs(p2.getX() - this.x) + Math.abs(p2.getY() - this.y);

        return (d1 <= d2) ? p1 : p2;
    }
}
