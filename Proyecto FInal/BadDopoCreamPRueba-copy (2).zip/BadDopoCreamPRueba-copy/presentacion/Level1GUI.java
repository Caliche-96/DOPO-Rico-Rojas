package presentacion;

import dominio.*;

/**
 * Level1GUI con coordenadas invertidas respecto a las originales que enviaste.
 * 
 */
public class Level1GUI extends LevelGUIBase {

    @Override
    protected void cargarNivel() {

        // Player:
        Player p = new Player(8, 14,1, "recursos/Vainilla.png");
        if (GameConfig.getPlayers() == 2) {
            Player p2 = new Player(8, 15, 2, "recursos/Vainilla.png");
            board.colocarPlayer2(p2);
        }

        board.colocarPlayer(p);

        
        board.agregarEnemy(new Troll(15, 7, Direccion.ESTE));
        board.agregarEnemy(new Maceta(6, 6));
        board.agregarEnemy(new Calamar(15, 10));


        // ---- BLOQUES INDESTRUCTIBLES 
        board.colocarIndestructible(1, 1);
        board.colocarIndestructible(1, 16);
        board.colocarIndestructible(16, 1);
        board.colocarIndestructible(16, 16);

        
        for (int x = 7; x <= 10; x++) board.colocarIndestructible(x, 7);

        
        for (int x = 7; x <= 10; x++) board.colocarIndestructible(x, 8);

        
        for (int x = 7; x <= 10; x++) board.colocarIndestructible(x, 9);
        
        for (int x = 7; x <= 10; x++) board.colocarIndestructible(x, 10);
        
        

        // ---- ICEBLOCKS (coordenadas invertidas) ----
        // Puntos individuales (swap each pair)
        int[][] icePoints = {
               
                {5,5},  
                {6,5},  
                {11,5}, 
                {12,5}, 
                {5,12}, 
                {6,12}, 
                {11,12},
                {12,12} 
        };
        for (int[] c : icePoints) {
            board.colocarIceBlock(c[0], c[1], true);
        }

        
        for (int x = 2; x <= 15; x++) board.colocarIceBlock(x, 1, true);

        
        for (int x = 2; x <= 15; x++) board.colocarIceBlock(x, 16, true);

       
        for (int y = 2; y <= 15; y++) board.colocarIceBlock(1, y, true);

        
        for (int y = 2; y <= 15; y++) board.colocarIceBlock(16, y, true);

       
        for (int y = 5; y <= 12; y++) board.colocarIceBlock(4, y, true);

        
        for (int y = 5; y <= 12; y++) board.colocarIceBlock(13, y, true);

        // ---- BANANAS 
       
        int[][] bananas = { 
                
                {3,4},{4,4},{13,4},{14,4},

                {3,5},{14,5},

               
                {7,6},{10,6},

                {6,8},{11,8},


                {6,9},{11,9},

               
                {7,11},{10,11},

                {3,12},{14,12},

              
                {3,13},{4,13},{13,13},{14,13}
        };

        for (int[] b : bananas) {
            board.agregarFruit(new Banana(b[0], b[1], "recursos/Banana.png"));
        }
    }
}

