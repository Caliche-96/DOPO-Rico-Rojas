package presentacion;

public class PlayerSkin {

    public static String currentSkin = "VANILLA"; 
    // valores posibles: "VANILLA", "CHOCOLATE", "FRESA"
    
    public static void setSkin(String s) {
        currentSkin = s;
    }

    public static String getSkin() {
        return currentSkin;
    }
}
