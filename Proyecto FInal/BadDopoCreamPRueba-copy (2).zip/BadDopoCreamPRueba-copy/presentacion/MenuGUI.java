package presentacion;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;

public class MenuGUI extends JFrame {

    private JButton btnPlay;
    private JButton btnScores;
    private JButton btnHelp;
    private JButton btnCredits;
    private JLabel background;
    

    public MenuGUI() {
        setTitle("Menu");
        setSize(600, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null); 

        //backgroundImage = new ImageIcon("recursos/2MenuGUI.png").getImage();

        prepareElements();
        prepareActions();

        setVisible(true);
    }

    /** 
     *  CREAR ELEMENTOS GRÁFICOS
     */
    private void prepareElements() {
        
        
        File file = new File("recursos/2MenuGUI.png");
        ImageIcon bgIcon = new ImageIcon(file.getAbsolutePath());
        background = new JLabel(bgIcon);
        background.setBounds(0, 0, 600, 500);
        
        // BOTÓN PLAY
        btnPlay = new JButton();
        btnPlay.setBounds(220, 180, 160, 40);
        add(btnPlay);
        btnPlay.setOpaque(false);
        btnPlay.setContentAreaFilled(false);
        btnPlay.setBorderPainted(false);

        // BOTÓN SCORES
        btnScores = new JButton();
        btnScores.setBounds(220, 230, 160, 40);
        add(btnScores);
        btnScores.setOpaque(false);
        btnScores.setContentAreaFilled(false);
        btnScores.setBorderPainted(false);

        // BOTÓN HELP
        btnHelp = new JButton();
        btnHelp.setBounds(220, 280, 160, 40);
        add(btnHelp);
        btnHelp.setOpaque(false);
        btnHelp.setContentAreaFilled(false);
        btnHelp.setBorderPainted(false);

        // BOTÓN CREDITS
        btnCredits = new JButton();
        btnCredits.setBounds(220, 330, 160, 40);
        add(btnCredits);
        btnCredits.setOpaque(false);
        btnCredits.setContentAreaFilled(false);
        btnCredits.setBorderPainted(false);
        add(background);
    }

    /**
     *  ACCIONES 
     */
    private void prepareActions() {

        // Acción general "En construcción"
        ActionListener constructionListener = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null,
                        "Esta sección está en construcción.",
                        "Información",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        };

        
        btnPlay.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                abrirPlayMenu();
            }
        });
        btnScores.addActionListener(constructionListener);
        btnHelp.addActionListener(constructionListener);
        btnCredits.addActionListener(constructionListener);
    }



    public static void main(String[] args) {
        new MenuGUI();
    }
    private void abrirPlayMenu() {
        new PlayMenuGUI();
        dispose();
    }

}
