package dominio;

import java.util.List;

public class Wave {
    private List<Fruit> frutas;

    public Wave(List<Fruit> frutas) {
        this.frutas = frutas;
    }

    public List<Fruit> getFrutas() {
        return frutas;
    }
}
