package dominio;

import java.util.ArrayList;
import java.util.List;

public class Nivel {

    private GameBoard board;
    private List<Wave> oleadas = new ArrayList<>();
    private int oleadaActual = 0;

    public Nivel(GameBoard board) {
        this.board = board;
    }

    public GameBoard getBoard() { return board; }

    // --- NUEVO ---
    public void agregarOleada(Wave wave) {
        oleadas.add(wave);
    }

    public void iniciarOleada(int i) {
        Wave w = oleadas.get(i);
        for (Fruit f : w.getFrutas()) {
            board.agregarFruit(f);
        }
    }

    /**
     * Actualiza el estado del nivel.
     * Retorna:
     * 0 = todo bien
     * 1 = jugador muerto
     * 2 = nivel completado
     */
    public int actualizar() {
        board.actualizarEnemigos();

        // colisión enemigo-jugador
        Player p = board.getPlayer();
        for (Enemy e : board.getEnemigos()) {
            if (e.getX() == p.getX() && e.getY() == p.getY()) return 1;
        }

        // ---- NUEVA LÓGICA DE OLEADAS ----
            if (board.todosFrutosRecogidos()) {
    
            // ¿Hay más oleadas?
            if (board.tieneMasOleadas()) {
                board.cargarSiguienteOleada();
                return 0;   // NO ha terminado el nivel, solo pasa de oleada
            }
    
            return 2;   // nivel completado
        }
    
        return 0;
    }
}
