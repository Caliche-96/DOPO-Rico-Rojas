package dominio;

public class BloqueIndestructible extends Bloque {
    private String spriteName;
    public BloqueIndestructible(int x, int y, String spriteName) {
        super(x, y);
        this.spriteName = spriteName;
    }

    @Override
    public boolean esTransitable() { return false; }

    @Override
    public boolean esDestructible() { return false; }

    @Override
    public String getSpriteName() { return spriteName; }
}
