package dominio;
import javax.swing.ImageIcon;

public class Uva extends Fruit {
    private ImageIcon sprite;
    public Uva(int x, int y) {
        super(x, y, 50); // 100 puntos
        this.sprite = new ImageIcon("recursos/Uva.png");
    }

    @Override
    public void recolectar(Player p) {
        p.addPuntos(puntos);
        // el manejo de eliminar la fruta del tablero lo hace Nivel/GameBoard
    }
    @Override
    public ImageIcon getSprite() { 
            return sprite; 
    }
}