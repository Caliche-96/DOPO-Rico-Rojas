package dominio;
import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

/**
 * GameBoard: matriz 18x18 con borde de bloques indestructibles.
 */
public class GameBoard {
    public static final int WIDTH = 18;
    public static final int HEIGHT = 18;

    private Celda[][] celdas;
    private List<Enemy> enemigos;
    private List<Fruit> frutas;
    private Player player;
    private Player player2; // puede ser null cuando solo 1 jugador
    
    public List<List<OleadaFruitData>> oleadas = new ArrayList<>();
    public int oleadaActual = 0;


    // sprite names path relativa
    private final String bloqueSprite;
    private final String iceSprite;

    public GameBoard(String bloqueSprite, String iceSprite) {
        this.bloqueSprite = bloqueSprite;
        this.iceSprite = iceSprite;

        celdas = new Celda[WIDTH][HEIGHT];
        for (int x = 0; x < WIDTH; x++) for (int y = 0; y < HEIGHT; y++) celdas[x][y] = new Celda();

        enemigos = new ArrayList<>();
        frutas = new ArrayList<>();

        inicializarBordes();
    }

    private void inicializarBordes() {
        for (int x = 0; x < WIDTH; x++) {
            colocarBloque(new BloqueIndestructible(x, 0, bloqueSprite));
            colocarBloque(new BloqueIndestructible(x, HEIGHT - 1, bloqueSprite));
        }
        for (int y = 0; y < HEIGHT; y++) {
            colocarBloque(new BloqueIndestructible(0, y, bloqueSprite));
            colocarBloque(new BloqueIndestructible(WIDTH - 1, y, bloqueSprite));
        }
    }

    public Celda getCelda(int x, int y) {
        if (!esPosicionValida(x, y)) return null;
        return celdas[x][y];
    }

    public boolean esPosicionValida(int x, int y) {
        return x >= 0 && x < WIDTH && y >= 0 && y < HEIGHT;
    }

    public void colocarBloque(Bloque b) {
        if (!esPosicionValida(b.getX(), b.getY())) return;
        celdas[b.getX()][b.getY()].setBloque(b);
    }

    public void removerBloque(int x, int y) {
        if (!esPosicionValida(x, y)) return;
        celdas[x][y].setBloque(null);
    }

    public void colocarPlayer(Player p) {
        this.player = p;
        celdas[p.getX()][p.getY()].setEntidad(p);
    }

    public Player getPlayer() { return player; }
    
    public void colocarPlayer2(Player p) {
        this.player2 = p;
        getCelda(p.getX(), p.getY()).setEntidad(p);
    }
    
    public Player getPlayer2() { return player2; }
    
    public void moverJugador(Player p, int nx, int ny) {
        if (!esPosicionValida(nx, ny)) return;
        Celda destino = getCelda(nx, ny);
    
        if (destino.tieneBloqueNoTransitable()) return;
        if (destino.estaOcupadaPorEntidad()) return;
    
        Celda origen = getCelda(p.getX(), p.getY());
        if (origen != null) origen.setEntidad(null);
    
        if (destino.getFruit() != null) {
            destino.getFruit().recolectar(p);
            frutas.remove(destino.getFruit());
            destino.setFruit(null);
        }
    
        p.setPosicion(nx, ny);
        destino.setEntidad(p);
    }

        
    public void moverPlayerA(int nx, int ny) {
        if (!esPosicionValida(nx, ny)) return;
        Celda destino = getCelda(nx, ny);
        if (destino.tieneBloqueNoTransitable()) return;
        if (destino.estaOcupadaPorEntidad()) return; // impedir mover sobre otra entidad

        // quitar del origen
        Celda origen = getCelda(player.getX(), player.getY());
        if (origen != null) origen.setEntidad(null);

        // recoger fruta si hay
        if (destino.getFruit() != null) {
            destino.getFruit().recolectar(player);
            frutas.remove(destino.getFruit());
            destino.setFruit(null);
        }

        // colocar player en destino
        player.setPosicion(nx, ny);
        destino.setEntidad(player);
    }

    public void agregarEnemy(Enemy e) {
        enemigos.add(e);
        getCelda(e.getX(), e.getY()).setEntidad(e);
    }

    public List<Enemy> getEnemigos() { return enemigos; }

    public void actualizarEnemigos() {
        // mover cada enemigo según sus reglas
        // para simplificar, removemos y recolocamos la entidad en celdas
        for (Enemy en : new ArrayList<>(enemigos)) {
            // quitar de su celda actual
            Celda actual = getCelda(en.getX(), en.getY());
            if (actual != null && actual.getEntidad() == en) actual.setEntidad(null);

            if (en instanceof Troll) {
                ((Troll) en).avanzar(this);
            }
            if (en instanceof Maceta) {
                ((Maceta) en).avanzar(this);
            }
            
            if (en instanceof Calamar) {
                ((Calamar) en).avanzar(this);
            }
            // poner en nueva celda (si existe)
            Celda nueva = getCelda(en.getX(), en.getY());
            if (nueva != null) {
                // si choca con player -> lo detectaremos en la capa nivel/gui
                nueva.setEntidad(en);
            }

        }
    }

    public void agregarFruit(Fruit f) {
        frutas.add(f);
        getCelda(f.getX(), f.getY()).setFruit(f);
    }

    public List<Fruit> getFrutas() { return frutas; }

    public boolean todosFrutosRecogidos() {
        return frutas.isEmpty();
    }

    
    public void cargarOleada(int index) {
        frutas.clear();
    
        if (index < 0 || index >= oleadas.size()) return;
    
        for (OleadaFruitData data : oleadas.get(index)) {
            try {
                Fruit fruta = data.tipo
                        .getConstructor(int.class, int.class)
                        .newInstance(data.x, data.y);
    
                agregarFruit(fruta);
    
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

        public boolean tieneMasOleadas() {
        return oleadaActual + 1 < oleadas.size();
    }
    
    public void cargarSiguienteOleada() {
        oleadaActual++;
        cargarOleada(oleadaActual);
    }


    // utilidad: colocar iceblock
    public void colocarIceBlock(int x, int y, boolean esOriginal) {
        Celda c = celdas[x][y];
        Bloque ice = new IceBlock(x, y, esOriginal, iceSprite);
        c.setBloque(ice);
        // la fruta queda abajo sin eliminarse
    }

    public void colocarIndestructible(int x, int y) {
    if (!esPosicionValida(x, y)) return;
    BloqueIndestructible b = new BloqueIndestructible(x, y, bloqueSprite);
    colocarBloque(b);   
    }

    
    public boolean hayBloqueEn(int x, int y) {
        if (!esPosicionValida(x,y)) return false;
        return celdas[x][y].getBloque() != null;
    }
    
    public boolean esIceBlock(int x, int y) {
        if (!esPosicionValida(x,y)) return false;
        Bloque b = celdas[x][y].getBloque();
        return b instanceof IceBlock;
    }
    
    public void romperIceBlock(int x, int y) {
        if (!esPosicionValida(x,y)) return;
        if (celdas[x][y].getBloque() instanceof IceBlock) {
            celdas[x][y].setBloque(null);
        }
    }
    
    public boolean hayEntidadEn(int x, int y) {
        if (!esPosicionValida(x,y)) return false;
        return celdas[x][y].getEntidad() != null;
    }
        public void limpiarFrutas() {
        for (int x = 1; x <= 16; x++) {
            for (int y = 1; y <= 16; y++) {
                celdas[x][y].setFruit(null);
            }
        }
    }
 
    

}





