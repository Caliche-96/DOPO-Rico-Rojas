package dominio;
import javax.swing.ImageIcon;

public abstract class Entidad {
    protected int x;
    protected int y;

    public Entidad(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() { return x; }
    public int getY() { return y; }

    public void setPosicion(int x, int y) { this.x = x; this.y = y; }

    // mover relativamentem (implementación distinta por tipo)
    public abstract void mover(int dx, int dy);
    public abstract ImageIcon getSprite();
}
