package dominio;
import javax.swing.*;
public class Player extends Entidad {
    private Direccion direccion;
    private int puntos;
    private String spriteName; // ruta relativa para presentacion
    private GameBoard board;
    private int idJugador;
    
    private ImageIcon sprite;
    
    public Player(int x, int y,int idJugador, String rutaBase) {
        super(x, y);
        this.idJugador = idJugador;
        this.direccion = Direccion.SUR;
        this.puntos = 0;
        this.sprite = new ImageIcon("recursos/Vainilla.png");
        
    }

    @Override
    public void mover(int dx, int dy) {
        this.x += dx;
        this.y += dy;
    }

    public void setDireccion(Direccion d) { this.direccion = d; }
    public Direccion getDireccion() { return direccion; }

    public void addPuntos(int p) { puntos += p; }
    public int getPuntos() { return puntos; }

    public String getSpriteName() { return spriteName; }
    
    public int getIdJugador() { return idJugador; }
    
    @Override
    public ImageIcon getSprite() { 
            return sprite; 
    }
}
