package dominio;
import javax.swing.ImageIcon;

public class Banana extends Fruit {
    private ImageIcon sprite;
    public Banana(int x, int y) {
        super(x, y, 100); // 100 puntos
        this.sprite = new ImageIcon("recursos/Banana.png");
    }

    @Override
    public void recolectar(Player p) {
        p.addPuntos(puntos);
        // el manejo de eliminar la fruta del tablero lo hace Nivel/GameBoard
    }
    @Override
    public ImageIcon getSprite() { 
            return sprite; 
    }
}
