package dominio;

public class OleadaFruitData {
    public int x, y;
    public Class<? extends Fruit> tipo;

    public OleadaFruitData(int x, int y, Class<? extends Fruit> tipo) {
        this.x = x;
        this.y = y;
        this.tipo = tipo;
    }
}
