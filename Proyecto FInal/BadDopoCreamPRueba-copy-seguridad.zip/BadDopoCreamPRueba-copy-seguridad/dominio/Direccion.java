package dominio;

public enum Direccion {
    NORTE, ESTE, SUR, OESTE;

    // Devuelve la dirección a la derecha (giro horario)
    public Direccion girarDerecha() {
        switch (this) {
            case NORTE: return ESTE;
            case ESTE: return SUR;
            case SUR: return OESTE;
            case OESTE: return NORTE;
        }
        return NORTE;
    }

    public int dx() {
        switch (this) {
            case ESTE: return 1;
            case OESTE: return -1;
            default: return 0;
        }
    }

    public int dy() {
        switch (this) {
            case SUR: return 1;
            case NORTE: return -1;
            default: return 0;
        }
    }
}
