package dominio;

public class IceBlock extends Bloque {
    private boolean esOriginal;
    private String spriteName;

    public IceBlock(int x, int y, boolean esOriginal, String spriteName) {
        super(x, y);
        this.esOriginal = esOriginal;
        this.spriteName = spriteName;
    }

    @Override
    public boolean esTransitable() { return false; }

    @Override
    public boolean esDestructible() { return true; }

    @Override
    public String getSpriteName() { return spriteName; }

    public boolean esOriginal() { return esOriginal; }
}
