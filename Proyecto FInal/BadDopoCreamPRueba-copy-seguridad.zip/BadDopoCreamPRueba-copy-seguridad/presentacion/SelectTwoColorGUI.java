package presentacion;

import javax.swing.*;
import java.awt.event.*;
import java.io.File;
import dominio.GameConfig;

public class SelectTwoColorGUI extends JFrame {

    private JButton p1Vanilla, p1Choco, p1Fresa;
    private JButton p2Vanilla, p2Choco, p2Fresa;
    private JButton btnBack;
    private JLabel background;

    private boolean p1Selected = false;

    public SelectTwoColorGUI() {

        setTitle("Choose Your Flavours");
        setSize(600, 500);
        setLocationRelativeTo(null);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        prepareElements();
        prepareActions();

        setVisible(true);
    }

    private void prepareElements() {

        background = new JLabel(new ImageIcon("recursos/4twoplayerGUI.png"));
        background.setBounds(0, 0, 600, 500);

        // Player 1 buttons
        p1Vanilla = createButton(110, 150);
        p1Choco   = createButton(240, 150);
        p1Fresa   = createButton(370, 150);

        // Player 2 buttons (disabled al inicio)
        p2Vanilla = createButton(110, 300); p2Vanilla.setEnabled(false);
        p2Choco   = createButton(240, 300); p2Choco.setEnabled(false);
        p2Fresa   = createButton(370, 300); p2Fresa.setEnabled(false);

        btnBack = createButton(200, 420);

        add(p1Vanilla); add(p1Choco); add(p1Fresa);
        add(p2Vanilla); add(p2Choco); add(p2Fresa);
        add(btnBack);
        add(background);
    }

    private JButton createButton(int x, int y) {
        JButton b = new JButton();
        b.setBounds(x, y, 100, 120);
        b.setOpaque(false);
        b.setContentAreaFilled(false);
        b.setBorderPainted(false);
        return b;
    }

    private void prepareActions() {

        // PLAYER 1 SELECT
        p1Vanilla.addActionListener(e -> selectP1("vainilla"));
        p1Choco.addActionListener(e -> selectP1("chocolate"));
        p1Fresa.addActionListener(e -> selectP1("fresa"));

        // PLAYER 2 SELECT
        p2Vanilla.addActionListener(e -> selectP2("vainilla"));
        p2Choco.addActionListener(e -> selectP2("chocolate"));
        p2Fresa.addActionListener(e -> selectP2("fresa"));

        // BACK
        btnBack.addActionListener(e -> {
            new PlayMenuGUI();
            dispose();
        });
    }

    private void selectP1(String color) {
        if (p1Selected) return;

        p1Selected = true;
        GameConfig.setColorP1(color);

        // Deshabilitar el color elegido en P2
        if (color.equals("vainilla")) p2Vanilla.setEnabled(false);
        if (color.equals("chocolate")) p2Choco.setEnabled(false);
        if (color.equals("fresa")) p2Fresa.setEnabled(false);

        // Activar botones de P2
        p2Vanilla.setEnabled(true);
        p2Choco.setEnabled(true);
        p2Fresa.setEnabled(true);
    }

    private void selectP2(String color) {
        GameConfig.setColorP2(color);
        new LevelSelectGUI();
        dispose();
    }
}
