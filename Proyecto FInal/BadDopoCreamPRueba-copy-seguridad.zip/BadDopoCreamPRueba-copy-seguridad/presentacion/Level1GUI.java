package presentacion;

import dominio.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Level1GUI con coordenadas invertidas respecto a las originales que enviaste.
 * 
 */
public class Level1GUI extends LevelGUIBase {

    @Override
    protected void cargarNivel() {
        nivel = new Nivel(board);
        this.nivel = nivel;
       
        // Player:
        Player p = new Player(8, 14,1, "recursos/Vainilla.png");
        if (GameConfig.getPlayers() == 2) {
            Player p2 = new Player(8, 15, 2, "recursos/Vainilla.png");
            board.colocarPlayer2(p2);
        }

        board.colocarPlayer(p);

        
        board.agregarEnemy(new Troll(15, 7, Direccion.ESTE));
        //board.agregarEnemy(new Maceta(6, 6));
        //board.agregarEnemy(new Calamar(15, 10));


        // ---- BLOQUES INDESTRUCTIBLES 
        board.colocarIndestructible(1, 1);
        board.colocarIndestructible(1, 16);
        board.colocarIndestructible(16, 1);
        board.colocarIndestructible(16, 16);

        
        for (int x = 7; x <= 10; x++) board.colocarIndestructible(x, 7);

        
        for (int x = 7; x <= 10; x++) board.colocarIndestructible(x, 8);

        
        for (int x = 7; x <= 10; x++) board.colocarIndestructible(x, 9);
        
        for (int x = 7; x <= 10; x++) board.colocarIndestructible(x, 10);
        
        

        // ---- ICEBLOCKS (coordenadas invertidas) ----
        // Puntos individuales (swap each pair)
        int[][] icePoints = {
               
                {5,5},  
                {6,5},  
                {11,5}, 
                {12,5}, 
                {5,12}, 
                {6,12}, 
                {11,12},
                {12,12} 
        };
        for (int[] c : icePoints) {
            board.colocarIceBlock(c[0], c[1], true);
        }

        
        for (int x = 2; x <= 15; x++) board.colocarIceBlock(x, 1, true);

        
        for (int x = 2; x <= 15; x++) board.colocarIceBlock(x, 16, true);

       
        for (int y = 2; y <= 15; y++) board.colocarIceBlock(1, y, true);

        
        for (int y = 2; y <= 15; y++) board.colocarIceBlock(16, y, true);

       
        for (int y = 5; y <= 12; y++) board.colocarIceBlock(4, y, true);

        
        for (int y = 5; y <= 12; y++) board.colocarIceBlock(13, y, true);

        GameBoard board = this.board; 
        // OLEADA 1: BANANAS
        List<OleadaFruitData> oleada1 = new ArrayList<>();
        oleada1.add(new OleadaFruitData(3,4, Banana.class));
        oleada1.add(new OleadaFruitData(4,4, Banana.class));
        oleada1.add(new OleadaFruitData(13,4, Banana.class));
        oleada1.add(new OleadaFruitData(14,4, Banana.class));
        oleada1.add(new OleadaFruitData(3,5, Banana.class));
        oleada1.add(new OleadaFruitData(14,5, Banana.class));
        oleada1.add(new OleadaFruitData(7,6, Banana.class));
        oleada1.add(new OleadaFruitData(10,6, Banana.class));
        oleada1.add(new OleadaFruitData(6,8, Banana.class));
        oleada1.add(new OleadaFruitData(11,8, Banana.class));
        oleada1.add(new OleadaFruitData(6,9, Banana.class));
        oleada1.add(new OleadaFruitData(11,9, Banana.class));
        oleada1.add(new OleadaFruitData(7,11, Banana.class));
        oleada1.add(new OleadaFruitData(10,11, Banana.class));
        oleada1.add(new OleadaFruitData(3,12, Banana.class));
        oleada1.add(new OleadaFruitData(14,12, Banana.class));
        oleada1.add(new OleadaFruitData(3,13, Banana.class));
        oleada1.add(new OleadaFruitData(4,13, Banana.class));
        oleada1.add(new OleadaFruitData(13,13, Banana.class));
        oleada1.add(new OleadaFruitData(14,13, Banana.class));
    
        board.oleadas.add(oleada1);
    
    
        // OLEADA 2: UVAS 
        List<OleadaFruitData> oleada2 = new ArrayList<>();
        oleada2.add(new OleadaFruitData(4,4, Uva.class));
        
        board.oleadas.add(oleada2);
    
        // ------------------------------
        //    INICIAR LA PRIMERA OLEADA
        // ------------------------------
        board.cargarOleada(0);
    }
}

