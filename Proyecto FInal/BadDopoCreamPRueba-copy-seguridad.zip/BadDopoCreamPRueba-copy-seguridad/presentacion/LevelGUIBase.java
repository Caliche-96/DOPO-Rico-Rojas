package presentacion;

import dominio.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.awt.image.BufferedImage;

public abstract class LevelGUIBase extends JFrame implements KeyListener {
    
    protected static final int CELL_SIZE = 32;

    protected Nivel nivel;
    protected GameBoard board;

    // SPRITES DEL PLAYER SEGÚN DIRECCIÓN
    protected final String P_DOWN  = "recursos/Vainilla.png";
    protected final String P_UP    = "recursos/Vup.png";
    protected final String P_LEFT  = "recursos/Vizq.png";
    protected final String P_RIGHT = "recursos/Vder.png";
    protected final String S_MACETA = "recursos/Maceta.png";
    protected final String S_CALAMAR = "recursos/Calamar.png";

    



    // OTROS SPRITES
    protected final String S_TROLL  = "recursos/Troll.png";
    protected final String S_BLOCK  = "recursos/Bloque.png";
    protected final String S_ICE    = "recursos/IceBlock.png";
    protected final String S_BANANA = "recursos/Banana.png";
    protected final String S_FONDO  = "recursos/FondoNivel.png";
    protected final String S_ICE_FRUIT = "recursos/IceFruit.png";

    protected Image imgPlayerUp, imgPlayerDown, imgPlayerLeft, imgPlayerRight;
    protected Image imgP2Up, imgP2Down, imgP2Left, imgP2Right;

    protected Image imgTroll, imgBlock, imgIce, imgBanana, imgFondo;
    protected Image imgIceFruit;
    protected Image imgMaceta;
    protected Image imgCalamar;


    protected JPanel panel;
    protected Timer gameTimer;
    protected boolean mostrarGrid = false;

    public LevelGUIBase() {
        setTitle("Nivel - Bad DOPO Cream");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        board = new GameBoard(S_BLOCK, S_ICE);
        cargarNivel();
        nivel = new Nivel(board);

        // Cargar sprites normales
        cargarSpritesPlayerPorSkin();


        imgTroll  = cargarImagen(S_TROLL);
        imgBlock  = cargarImagen(S_BLOCK);
        imgIce    = cargarImagen(S_ICE);
        imgBanana = cargarImagen(S_BANANA);
        imgMaceta = cargarImagen(S_MACETA);
        imgCalamar= cargarImagen(S_CALAMAR); 

        imgIceFruit = cargarImagen(S_ICE_FRUIT);


        //  Fondo ahora escalado con alta calidad una sola vez
        imgFondo = cargarFondo(
                S_FONDO,
                GameBoard.WIDTH * CELL_SIZE,
                GameBoard.HEIGHT * CELL_SIZE
        );

        panel = new JPanel() {
            @Override
            public Dimension getPreferredSize() {
                return new Dimension(GameBoard.WIDTH * CELL_SIZE, GameBoard.HEIGHT * CELL_SIZE);
            }

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                dibujarTablero(g);
            }
        };

        add(panel);
        pack();
        setLocationRelativeTo(null);
        addKeyListener(this);
        setVisible(true);
        if (GameConfig.getPlayers() == 2)
            cargarSpritesPlayer2();

        gameTimer = new Timer(350, e -> {
            int resultado = nivel.actualizar();

            if (resultado == 1) {
                JOptionPane.showMessageDialog(this, "Un enemigo te alcanzó.", "Perdiste", JOptionPane.WARNING_MESSAGE);
                reiniciar();
            }
            else if (resultado == 2) {
                gameTimer.stop();
                JOptionPane.showMessageDialog(this, "¡Nivel completado! Puntos: " + board.getPlayer().getPuntos());
                dispose();
                new LevelSelectGUI().setVisible(true);
            }

            panel.repaint();
        });

        gameTimer.start();
    }
    
    private void cargarSpritesPlayerPorSkin() {
    
        String skin = GameConfig.getColorP1();
    
        switch (skin) {
        
                case "chocolate":
                    imgPlayerDown  = cargarImagen("recursos/Chocolate.png");
                    imgPlayerUp    = cargarImagen("recursos/Cup.png");
                    imgPlayerLeft  = cargarImagen("recursos/Cizq.png");
                    imgPlayerRight = cargarImagen("recursos/Cder.png");
                    break;
        
                case "fresa":
                    imgPlayerDown  = cargarImagen("recursos/Fresa.png");
                    imgPlayerUp    = cargarImagen("recursos/Fup.png");
                    imgPlayerLeft  = cargarImagen("recursos/Fizq.png");
                    imgPlayerRight = cargarImagen("recursos/Fder.png");
                    break;
        
                default: // VANILLA
                    imgPlayerDown  = cargarImagen("recursos/Vainilla.png");
                    imgPlayerUp    = cargarImagen("recursos/Vup.png");
                    imgPlayerLeft  = cargarImagen("recursos/Vizq.png");
                    imgPlayerRight = cargarImagen("recursos/Vder.png");
                    break;
            }
    }
        
    protected void cargarSpritesPlayer2() {
        String skin = GameConfig.getColorP2();
    
        switch (skin) {
            case "chocolate":
                imgP2Down  = cargarImagen("recursos/Chocolate.png");
                imgP2Up    = cargarImagen("recursos/Cup.png");
                imgP2Left  = cargarImagen("recursos/Cizq.png");
                imgP2Right = cargarImagen("recursos/Cder.png");
                break;
    
            case "fresa":
                imgP2Down  = cargarImagen("recursos/Fresa.png");
                imgP2Up    = cargarImagen("recursos/Fup.png");
                imgP2Left  = cargarImagen("recursos/Fizq.png");
                imgP2Right = cargarImagen("recursos/Fder.png");
                break;
    
            default:
                imgP2Down  = cargarImagen("recursos/Vainilla.png");
                imgP2Up    = cargarImagen("recursos/Vup.png");
                imgP2Left  = cargarImagen("recursos/Vizq.png");
                imgP2Right = cargarImagen("recursos/Vder.png");
                break;
        }
    }


    /** MÉTODO ABSTRACTO QUE DEFINE LOS CONTENIDOS DEL NIVEL */
    protected abstract void cargarNivel();

    /** Reinicia solo el nivel actual */
    protected void reiniciar() {
        gameTimer.stop();
        cargarSpritesPlayerPorSkin();

        board = new GameBoard(S_BLOCK, S_ICE);
        cargarNivel();
        nivel = new Nivel(board);

        // Fondo debe recalcularse también
        imgFondo = cargarFondo(
                S_FONDO,
                GameBoard.WIDTH * CELL_SIZE,
                GameBoard.HEIGHT * CELL_SIZE
        );

        gameTimer.start();
    }

    /** Cargar sprites de 32x32 */
    protected Image cargarImagen(String ruta) {
        File f = new File(ruta);
        if (!f.exists()) {
            Image tmp = new BufferedImage(CELL_SIZE, CELL_SIZE, BufferedImage.TYPE_INT_RGB);
            Graphics g = tmp.getGraphics();
            g.setColor(Color.MAGENTA);
            g.fillRect(0,0,CELL_SIZE,CELL_SIZE);
            return tmp;
        }
        return new ImageIcon(ruta).getImage().getScaledInstance(CELL_SIZE, CELL_SIZE, Image.SCALE_SMOOTH);
    }

    /** Cargar fondo con escalado de alta calidad */
    protected Image cargarFondo(String ruta, int ancho, int alto) {
        ImageIcon icon = new ImageIcon(ruta);
        Image src = icon.getImage();

        BufferedImage scaled = new BufferedImage(ancho, alto, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = scaled.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        g2.drawImage(src, 0, 0, ancho, alto, null);
        g2.dispose();

        return scaled;
    }

    /** Dibujo general */
    protected void dibujarTablero(Graphics g) {

        g.drawImage(imgFondo, 0, 0, null);

        for (int x = 0; x < GameBoard.WIDTH; x++) {
            for (int y = 0; y < GameBoard.HEIGHT; y++) {

                Celda c = board.getCelda(x,y);
                int px = x * CELL_SIZE;
                int py = y * CELL_SIZE;

                
                // Si hay iceblock y además hay fruta => dibujar IceFruit (prioritario)
                if (c.getBloque() != null && c.getBloque() instanceof IceBlock && c.getFruit() != null) {
                    g.drawImage(imgIceFruit, px, py, null);
                }
                // Bloques (indestructible o ice)
                else if (c.getBloque() != null) {
                    if (c.getBloque().getSpriteName().equals(S_BLOCK))
                        g.drawImage(imgBlock, px, py, null);
                    else
                        g.drawImage(imgIce, px, py, null);
                }

                // Si no hay ice encima y hay fruta -> dibujar banana
                // (si hay ice + fruit ya se pintó como imgIceFruit en la rama anterior)
                Fruit f = c.getFruit();
                if (c.getFruit() != null && !(c.getBloque() instanceof IceBlock)) {
                   g.drawImage(f.getSprite().getImage(), px, py, null);
                }

                

                
                Entidad e = c.getEntidad();
                if (e != null) {
                    Image img = e.getSprite().getImage();
                    g.drawImage(img, px, py, null);
                }


                if (mostrarGrid) {
                    g.setColor(new Color(0, 255, 0, 80));
                    g.drawRect(px, py, CELL_SIZE, CELL_SIZE);
                }
            }
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {

        int code = e.getKeyCode();
        Player p = board.getPlayer();
        if (p == null) return;

        int nx = p.getX();
        int ny = p.getY();

        if (code == KeyEvent.VK_LEFT)  { nx--; p.setDireccion(Direccion.OESTE); }
        else if (code == KeyEvent.VK_RIGHT) { nx++; p.setDireccion(Direccion.ESTE); }
        else if (code == KeyEvent.VK_UP)    { ny--; p.setDireccion(Direccion.NORTE); }
        else if (code == KeyEvent.VK_DOWN)  { ny++; p.setDireccion(Direccion.SUR); }
        else if (code == KeyEvent.VK_SPACE) {
        
            // Si hay hielo en la dirección --> romper
            if (hayHieloEnFrente()) {
                romperLineaHielo(p);
            }
            // Si no hay --> crear
            else {
                generarLineaHielo(p);
            }
            return;
        }
        
            
            
        else if (code == KeyEvent.VK_C) {
            mostrarGrid = !mostrarGrid;
            panel.repaint();
            return;
        
        }

        board.moverPlayerA(nx, ny);
        
        
        
        Player p2 = board.getPlayer2();

        if (p2 != null) {
            int x2 = p2.getX(), y2 = p2.getY();
        
            if (code == KeyEvent.VK_A) { x2--; p2.setDireccion(Direccion.OESTE); }
            else if (code == KeyEvent.VK_D) { x2++; p2.setDireccion(Direccion.ESTE); }
            else if (code == KeyEvent.VK_W) { y2--; p2.setDireccion(Direccion.NORTE); }
            else if (code == KeyEvent.VK_S) { y2++; p2.setDireccion(Direccion.SUR); }
        
            else if (code == KeyEvent.VK_Z) {
        
                // Si hay hielo en frente de P2
                if (hayHieloEnFrenteDe(p2)) romperLineaHielo(p2);
                else generarLineaHielo(p2);
        
                return;
            }
        
            board.moverJugador(p2, x2, y2);
        }


        for (Enemy en : board.getEnemigos()) {
            if (en.getX()==p.getX() && en.getY()==p.getY()) {
                JOptionPane.showMessageDialog(this,"Te alcanzó un enemigo.");
                reiniciar();
                return;
            }
        }

        panel.repaint();
    }
    
    
    private boolean hayHieloEnFrenteDe(Player p) {
        int dx=0, dy=0;
    
        switch (p.getDireccion()) {
            case NORTE: dy=-1; break;
            case SUR: dy=1; break;
            case ESTE: dx=1; break;
            case OESTE: dx=-1; break;
        }
    
        int nx = p.getX()+dx;
        int ny = p.getY()+dy;
    
        if (!board.esPosicionValida(nx, ny)) return false;
    
        return board.esIceBlock(nx, ny);
    }

    @Override public void keyTyped(KeyEvent e) {}
    @Override public void keyReleased(KeyEvent e) {}
    private boolean hayHieloEnFrente() {
    
        Player p = board.getPlayer();
        if (p == null) return false;
    
        int dx = 0, dy = 0;
        switch (p.getDireccion()) {
            case NORTE: dy = -1; break;
            case SUR:   dy = 1;  break;
            case ESTE:  dx = 1;  break;
            case OESTE: dx = -1; break;
        }
    
        int nx = p.getX() + dx;
        int ny = p.getY() + dy;
    
        if (!board.esPosicionValida(nx, ny)) return false;
    
        Celda c = board.getCelda(nx, ny);
    
        return c.getBloque() instanceof IceBlock;
    }

    
    
    protected void generarLineaHielo(Player p) {
    
        // obtener dirección del player
        final int dx, dy;
        switch (p.getDireccion()) {
            case NORTE -> { dx = 0;  dy = -1; }
            case SUR   -> { dx = 0;  dy = 1; }
            case ESTE  -> { dx = 1;  dy = 0; }
            case OESTE -> { dx = -1; dy = 0; }
            default    -> { return; }
        }
    
        // posición inicial frente al player
        final int startX = p.getX() + dx;
        final int startY = p.getY() + dy;
    
        // Timer para animación
        Timer iceTimer = new Timer(80, null);
    
        // Variables independientes (clase anónima para mutarlas)
        final int[] pos = { startX, startY };
    
        iceTimer.addActionListener(e -> {
    
            int x = pos[0];
            int y = pos[1];
    
            if (!board.esPosicionValida(x, y)) {
                iceTimer.stop();
                return;
            }
    
            Celda c = board.getCelda(x, y);
    
            //  DETENER SI HAY BLOQUE O ICEBLOCK (NO se rompe)
            if (c.getBloque() != null) {
                iceTimer.stop();
                return;
            }
    
            //  DETENER SI HAY ENTIDAD (player/enemy)
            if (c.getEntidad() != null) {
                iceTimer.stop();
                return;
            }
    
            //  SI HAY FRUTA → queda debajo del hielo
            // (NO se elimina, GameBoard ya soporta esto)
            board.colocarIceBlock(x, y, true);
    
            panel.repaint();
    
            // avanzar
            pos[0] += dx;
            pos[1] += dy;
        });
    
        iceTimer.start();
    }
    
    protected void romperLineaHielo(Player p) {
    
        // obtener dirección del player
        final int dx, dy;
        switch (p.getDireccion()) {
            case NORTE -> { dx = 0;  dy = -1; }
            case SUR   -> { dx = 0;  dy = 1; }
            case ESTE  -> { dx = 1;  dy = 0; }
            case OESTE -> { dx = -1; dy = 0; }
            default    -> { return; }
        }
    
        final int startX = p.getX() + dx;
        final int startY = p.getY() + dy;
    
        // primera casilla
        if (!board.esPosicionValida(startX, startY)) return;
    
        Celda primera = board.getCelda(startX, startY);
    
        // si no hay hielo no romper
        if (!(primera.getBloque() instanceof IceBlock)) return;
    
        // CRISTAL: animación en hilo
        new Thread(() -> {
    
            final int[] pos = { startX, startY };
    
            while (board.esPosicionValida(pos[0], pos[1])) {
    
                int cx = pos[0];
                int cy = pos[1];
    
                Celda c = board.getCelda(cx, cy);
    
                // detener en bloque indestructible
                if (c.getBloque() instanceof BloqueIndestructible)
                    break;
    
                // detener si ya no hay más hielo
                if (!(c.getBloque() instanceof IceBlock))
                    break;
    
                // romper
                board.removerBloque(cx, cy);
                panel.repaint();
    
                try {
                    Thread.sleep(80);
                } catch (Exception ex) {}
    
                // avanzar
                pos[0] += dx;
                pos[1] += dy;
            }
    
        }).start();
    }







}

