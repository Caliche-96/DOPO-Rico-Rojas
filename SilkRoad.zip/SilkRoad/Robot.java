
/**
 * Write a description of class Robot here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
/**
 * Robot en la ruta (usando Circle).
 */
public class Robot extends Circle {
    private int startX;
    private int startY;
    private int xCell;
    private int yCell;          //Esta parte de celdas no deberia ir. Puesto que ya es de Rectangle
    private int startIndex;
    private int spiralIndex;
    private int cellSize;
    private int offsetX;
    private int offsetY;
    private String color;

    // ganancias
    private int totalProfit;
    private int lastProfit;

    public Robot(int xCell, int yCell, int startIndex,
                 int cellSize, int offsetX, int offsetY, String color) {
        super();
        this.startX = xCell;
        this.startY = yCell;
        this.xCell = xCell;
        this.yCell = yCell;
        this.startIndex = startIndex;
        this.spiralIndex = startIndex; // empezar en el índice correcto
        this.cellSize = cellSize;
        this.offsetX = offsetX;
        this.offsetY = offsetY;
        this.color = color;

        this.totalProfit = 0;
        this.lastProfit = 0;

        int size = cellSize - 5;
        int margin = (cellSize - size) / 2;

        this.changeSize(size);
        this.changeColor(color);

        // Ajuste manual para centrar dentro de la celda (tal como pediste: +50 en X)
        this.moveHorizontal(offsetX + xCell * cellSize + margin + 50);
        this.moveVertical(offsetY + yCell * cellSize + margin);

        this.makeVisible();
    }

    /**
     * Mueve paso a paso por el spiralPath hasta targetIndex (puede avanzar o retroceder).
     * Imprime el número de casilla en cada paso y ralentiza con Canvas.wait.
     */
    public void moveAlongSpiral(int targetIndex, int[][] spiralPath) {
        if (targetIndex < 0 || targetIndex >= spiralPath.length) return;

        int step = (targetIndex > spiralIndex) ? 1 : -1;

        while (spiralIndex != targetIndex) {
            spiralIndex += step;

            // Seguridad por si se cruza algún límite (no debería ocurrir)
            if (spiralIndex < 0) spiralIndex = 0;
            if (spiralIndex >= spiralPath.length) spiralIndex = spiralPath.length - 1;

            int newX = spiralPath[spiralIndex][0];
            int newY = spiralPath[spiralIndex][1];

            int dx = (newX - xCell) * cellSize;
            int dy = (newY - yCell) * cellSize;
            this.moveHorizontal(dx);
            this.moveVertical(dy);

            xCell = newX;
            yCell = newY;

            System.out.println("Robot avanzó a la casilla " + spiralIndex);

            // hacer visible el avance (pausa)
            Canvas.getCanvas().wait(200);
        }
    }

    /**
     * Registrar la ganancia que obtuvo el robot en un movimiento.
     */
    public void addProfit(int profit) {
        this.totalProfit += profit;
        this.lastProfit = profit;
    }

    /**
     * Regresa a la posición inicial (tanto lógica como gráfica) y restablece spiralIndex.
     */
    public void reset() {
        int dx = (startX - xCell) * cellSize;
        int dy = (startY - yCell) * cellSize;
        this.moveHorizontal(dx);
        this.moveVertical(dy);
        xCell = startX;
        yCell = startY;
        spiralIndex = startIndex;
    }

    /**
     * Parpadea el robot n veces (para destacar al mejor robot).
     */
    public void blink(int times) {
        for (int i = 0; i < times; i++) {
            this.makeInvisible();
            Canvas.getCanvas().wait(250);
            this.makeVisible();
            Canvas.getCanvas().wait(250);
        }
    }

    // Getters útiles
    public String getColor() { return color; }
    public int getTotalProfit() { return totalProfit; }
    public int getLastProfit() { return lastProfit; }
    public int getXCell() { return xCell; }
    public int getYCell() { return yCell; }
    public int getSpiralIndex() { return spiralIndex; }
}


