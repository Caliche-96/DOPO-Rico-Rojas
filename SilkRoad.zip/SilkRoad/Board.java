
/**
 * Write a description of class Tablero here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import java.util.ArrayList;

/**
 * Representa el tablero de NxN casillas y dibuja la rejilla (bordes).
 */
public class Board {
    private int size;
    private int cellSize;
    private ArrayList<Rectangle> cells;
    private int offsetX;
    private int offsetY;

    public Board(int size, int cellSize, int offsetX, int offsetY) {
        this.size = size;
        this.cellSize = cellSize;
        this.offsetX = offsetX;
        this.offsetY = offsetY;
        this.cells = new ArrayList<>();

        drawGrid();
    }

    private void drawGrid() {
        for (int row = 0; row < size; row++) {
            for (int col = 0; col < size; col++) {
                Rectangle outer = new Rectangle();
                outer.changeSize(cellSize, cellSize);
                outer.changeColor("white");
                outer.moveHorizontal(offsetX + col * cellSize);
                outer.moveVertical(offsetY + row * cellSize);
                outer.makeVisible();

                Rectangle border = new Rectangle();
                border.changeSize(cellSize - 1, cellSize - 1);
                border.changeColor("lightGray");
                border.moveHorizontal(offsetX + col * cellSize + 1);
                border.moveVertical(offsetY + row * cellSize + 1);
                border.makeVisible();

                cells.add(outer);
                cells.add(border);
            }
        }
    }

    // Getters para que SilkRoad pueda acceder
    public int getSize() { return size; }
    public int getCellSize() { return cellSize; }
    public int getOffsetX() { return offsetX; }
    public int getOffsetY() { return offsetY; }
}

