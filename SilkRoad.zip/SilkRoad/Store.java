
/**
 * Write a description of class Tienda here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
/**
 * Tienda en la ruta (usando Rectangle).
 */
public class Store extends Rectangle {
    private int xCell;
    private int yCell;      //Esta parte de celdas no deberia ir. Puesto que ya es de Rectangle
    private int initialTenges;
    private int tenges;
    private int timesEmptied;
    private String color;
    private String originalColor;

    public Store(int xCell, int yCell, int tenges, int cellSize, int offsetX, int offsetY, String color) {
        super();
        this.xCell = xCell;
        this.yCell = yCell;
        this.initialTenges = tenges;
        this.tenges = tenges;
        this.color = color;
        this.originalColor = color;
        this.timesEmptied = 0;

        int size = cellSize - 5;   // un poco más pequeño que la celda
        int margin = (cellSize - size) / 2;

        this.changeSize(size, size);
        this.changeColor(color);
        this.moveHorizontal(offsetX + xCell * cellSize + margin);
        this.moveVertical(offsetY + yCell * cellSize + margin);
        this.makeVisible();
    }

    /**
     * Se llama cuando un robot recoge la tienda: se vacía y se pone blanca.
     */
    public void collect() {
        this.tenges = 0;
        this.timesEmptied++;
        this.changeColor("white");
        this.color = "white";
    }

    /**
     * Reponer tenges a su valor inicial. Si estaba blanca (vacía),
     * recupera su color original.
     */
    public void resupply() {
        this.tenges = initialTenges;
        if ("white".equals(this.color)) {
            this.color = this.originalColor;
            this.changeColor(this.color);
        }
    }

    // Getters
    public int getXCell() { return xCell; }
    public int getYCell() { return yCell; }
    public int getTenges() { return tenges; }
    public int getTimesEmptied() { return timesEmptied; }
    public String getColor() { return color; }
}
