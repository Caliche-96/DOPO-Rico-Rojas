
/**
 * Clase principal que controla la simulación SilkRoad.
 * Gestiona el tablero, tiendas, robots, y las ganancias por día.
 */
import java.util.*;

public class SilkRoad {
    private Board board;
    private ArrayList<Store> stores;
    private ArrayList<Robot> robots;
    private int day;
    private int[][] spiralPath;
    private Map<Integer, int[]> cellMap;
    private int lastProfit;
    private Scanner sc;

    // Colores disponibles (sin "white")
    private List<String> robotColors;
    private List<String> storeColors;
    private Random rnd;

    public SilkRoad() {
        this.board = new Board(10, 30, 10, 10); // tablero 10x10
        this.stores = new ArrayList<>();
        this.robots = new ArrayList<>();
        this.day = 0;
        this.spiralPath = SpiralPath.generateSpiral(board.getSize());
        this.cellMap = SpiralPath.generateSpiralMap(board.getSize());
        this.lastProfit = 0;
        this.sc = new Scanner(System.in);
        this.rnd = new Random();

        // Colores permitidos (sin blanco)
        List<String> baseColors = Arrays.asList(
            "red","blue","green","yellow","magenta","orange"
        );
        this.robotColors = new ArrayList<>(baseColors);
        this.storeColors = new ArrayList<>(baseColors);
    }

    private String getUniqueColor(List<String> available) {
        if (available.isEmpty()) {
            available.addAll(Arrays.asList(
                "red","blue","green","yellow","magenta","orange"
            ));
        }
        int idx = rnd.nextInt(available.size());
        String color = available.get(idx);
        available.remove(idx);
        return color;
    }

    /**
     * Retorna el índice (número de casilla) dentro del spiralPath para las coordenadas x,y.
     */
    private int findSpiralIndex(int x, int y) {
        for (int i = 0; i < spiralPath.length; i++) {
            if (spiralPath[i][0] == x && spiralPath[i][1] == y) return i;
        }
        return -1;
    }

    /**
     * Bucle principal: pide al usuario por día qué añadir y procesa el día.
     */
    public void runSimulation() {
        System.out.print("Ingrese el número de días de la simulación: ");
        int n = sc.nextInt();

        for (int d = 0; d < n; d++) {
            day++;
            System.out.println("\n=== Día " + day + " ===");

            // pedir tipo 1 o 2 (validación)
            int tipo;
            while (true) {
                System.out.print("¿Qué desea añadir? (1 = Robot, 2 = Tienda): ");
                tipo = sc.nextInt();
                if (tipo == 1 || tipo == 2) break;
                System.out.println("Número no válido. Debe ingresar 1 o 2.");
            }

            // pedir número de casilla
            int casilla;
            while (true) {
                System.out.print("Ingrese número de casilla (0 - " + (spiralPath.length - 1) + "): ");
                casilla = sc.nextInt();
                if (cellMap.containsKey(casilla)) break;
                System.out.println("Casilla inválida. Intente de nuevo.");
            }

            int[] coords = cellMap.get(casilla);
            int x = coords[0];
            int y = coords[1];

            if (tipo == 1) {
                addRobot(x, y, casilla);
            } else {
                System.out.print("Ingrese número de tenges para la tienda: ");
                int tenges = sc.nextInt();
                addStore(x, y, tenges, casilla);
            }

            // procesar día
            nextDay();
        }

        // resumen final
        System.out.println("\n=== Resumen Final ===");
        System.out.println("Días simulados: " + n);
        for (Store s : stores) {
            int idx = findSpiralIndex(s.getXCell(), s.getYCell());
            System.out.println("Tienda en casilla " + idx + " fue vaciada " + s.getTimesEmptied() + " veces.");
        }
        for (Robot r : robots) {
            System.out.println("Robot de color " + r.getColor() + " acumuló " + r.getTotalProfit() + " tenges en total.");
        }
        System.out.println("Fin de la simulación.");
    }

    /**
     * Añade un robot en la casilla indicada (usa índice de espiral para inicialización).
     */
    public void addRobot(int x, int y, int casilla) {
        if (isCellFree(x, y)) {
            String color = getUniqueColor(robotColors);
            int spiralIdx = findSpiralIndex(x, y);
            Robot r = new Robot(x, y, spiralIdx,
                                board.getCellSize(),
                                board.getOffsetX(),
                                board.getOffsetY(),
                                color);
            robots.add(r);
            System.out.println("Robot creado de color " + color + " en casilla " + casilla);
        } else {
            System.out.println("La casilla ya está ocupada, no se añadió el robot.");
        }
    }

    /**
     * Añade una tienda en la casilla indicada.
     */
    public void addStore(int x, int y, int tenges, int casilla) {
        if (isCellFree(x, y)) {
            String color = getUniqueColor(storeColors);
            Store s = new Store(x, y, tenges,
                                board.getCellSize(),
                                board.getOffsetX(),
                                board.getOffsetY(),
                                color);
            stores.add(s);
            System.out.println("Tienda creada de color " + color + " en casilla " + casilla);
        } else {
            System.out.println("La casilla ya está ocupada, no se añadió la tienda.");
        }
    }

    /**
     * Procesa un día: reabastece, resetea robots, calcula y ejecuta movimientos.
     */
    public void nextDay() {
        System.out.println("Procesando el día " + day + "...");
        // 1) reabastecer tiendas (las que estaban blancas recuperan su color interno)
        for (Store s : stores) {
            s.resupply();
            int idx = findSpiralIndex(s.getXCell(), s.getYCell());
            System.out.println("Tienda en casilla " + idx + " reabastecida con " + s.getTenges() + " tenges.");
        }

        // 2) volver robots a su posición inicial
        for (Robot r : robots) r.reset();

        // 3) evaluar y mover robots
        int dailyProfit = moveRobots();
        System.out.println("Ganancia del día " + day + ": " + dailyProfit);

        // 4) ganancia máxima teórica (usando misma métrica por casilla)
        lastProfit = calculateProfit();
        System.out.println("Ganancia máxima posible tras este día: " + lastProfit);
    }

    /**
     * Asigna robots a tiendas (greedy por profit) y mueve los robots casilla por casilla.
     * Retorna la ganancia total del día.
     */
    public int moveRobots() {
        class MoveOption {
            Robot robot;
            Store store;
            int profit;
            int dist;
            int storeIndex;
            MoveOption(Robot r, Store s, int profit, int dist, int storeIndex) {
                this.robot = r;
                this.store = s;
                this.profit = profit;
                this.dist = dist;
                this.storeIndex = storeIndex;
            }
        }

        List<MoveOption> options = new ArrayList<>();

        // Construir todas las opciones robot–tienda usando índices de casilla
        for (Robot r : robots) {
            int robotIdx = r.getSpiralIndex();
            for (Store s : stores) {
                int storeIdx = findSpiralIndex(s.getXCell(), s.getYCell());
                if (storeIdx == -1) continue;
                int dist = Math.abs(robotIdx - storeIdx);
                int profit = s.getTenges() - dist;
                if (profit > 0) options.add(new MoveOption(r, s, profit, dist, storeIdx));
            }
        }

        // Ordenar por profit desc; en empate, por menor distancia
        options.sort((a, b) -> {
            if (b.profit != a.profit) return b.profit - a.profit;
            return a.dist - b.dist;
        });

        Set<Robot> usedRobots = new HashSet<>();
        Set<Store> usedStores = new HashSet<>();
        int totalProfit = 0;

        Robot bestRobot = null;
        int bestProfit = -1;

        for (MoveOption opt : options) {
            if (!usedRobots.contains(opt.robot) && !usedStores.contains(opt.store)) {
                // mover paso a paso por el spiralPath (adelante o atrás)
                opt.robot.moveAlongSpiral(opt.storeIndex, spiralPath);

                // actualizar ganancias del robot
                opt.robot.addProfit(opt.profit);

                // la tienda se vacía (se vuelve blanca y se incrementa contador)
                opt.store.collect();

                usedRobots.add(opt.robot);
                usedStores.add(opt.store);

                totalProfit += opt.profit;

                // guardamos el mejor movimiento simple (mayor profit individual)
                if (opt.profit > bestProfit) {
                    bestProfit = opt.profit;
                    bestRobot = opt.robot;
                }

                System.out.println("Robot llegó a la tienda con profit " + opt.profit);
            }
        }

        // si hay un robot ganador, informar y hacer parpadear
        if (bestRobot != null) {
            System.out.println("El robot de color " + bestRobot.getColor() +
                               " con una ganancia de " + bestProfit +
                               " fue el que más ganancia generó.");
            bestRobot.blink(3);
        }

        return totalProfit;
    }

    /**
     * Verifica si la celda está libre (sin tienda ni robot).
     */
    private boolean isCellFree(int x, int y) {
        for (Store s : stores) if (s.getXCell() == x && s.getYCell() == y) return false;
        for (Robot r : robots) if (r.getXCell() == x && r.getYCell() == y) return false;
        return true;
    }

    /**
     * Calcula la ganancia máxima teórica usando la métrica por número de casilla (índices).
     */
    private int calculateProfit() {
        int maxProfit = 0;
        for (Robot r : robots) {
            int rIdx = r.getSpiralIndex();
            for (Store s : stores) {
                int sIdx = findSpiralIndex(s.getXCell(), s.getYCell());
                if (sIdx == -1) continue;
                int dist = Math.abs(rIdx - sIdx);
                int gain = s.getTenges() - dist;
                if (gain > maxProfit) maxProfit = gain;
            } 
        }
        return maxProfit;
    }
}

