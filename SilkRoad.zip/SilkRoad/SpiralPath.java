
/**
 * Write a description of class SpiralPath here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
/**
 * Genera una trayectoria en espiral sobre un tablero de n x n.
 */
import java.util.HashMap;
import java.util.Map;

public class SpiralPath {

    /**
     * Genera las coordenadas en espiral para un tablero de n*n.
     * Devuelve un arreglo path[i] = {x,y}, donde i es el número de casilla.
     */
    public static int[][] generateSpiral(int n) {
        int[][] path = new int[n * n][2];
        boolean[][] visited = new boolean[n][n];

        // Movimientos: derecha, abajo, izquierda, arriba
        int[] dx = {1, 0, -1, 0};
        int[] dy = {0, 1, 0, -1};

        int x = 0, y = 0, dir = 0;
        for (int i = 0; i < n * n; i++) {
            path[i][0] = x;
            path[i][1] = y;
            visited[y][x] = true;

            int nx = x + dx[dir];
            int ny = y + dy[dir];

            // Cambiar dirección si salimos del tablero o ya visitamos
            if (nx < 0 || nx >= n || ny < 0 || ny >= n || visited[ny][nx]) {
                dir = (dir + 1) % 4; // girar a la derecha
                nx = x + dx[dir];
                ny = y + dy[dir];
            }

            x = nx;
            y = ny;
        }
        return path;
    }

    /**
     * Crea un mapa de casilla → {x,y}, usando la espiral.
     */
    public static Map<Integer, int[]> generateSpiralMap(int n) {
        int[][] spiral = generateSpiral(n);
        Map<Integer, int[]> map = new HashMap<>();
        for (int i = 0; i < spiral.length; i++) {
            map.put(i, new int[]{spiral[i][0], spiral[i][1]});
        }
        return map;
    }
}

