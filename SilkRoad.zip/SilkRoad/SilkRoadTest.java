import java.io.*;

public class SilkRoadTest {
    public static void main(String[] args) {
        // Simulamos la entrada de usuario para los 6 días
        String inputData =
            "6\n" +     // Número de días
            "1\n20\n" + // Día 1 -> Añadir robot en casilla 20
            "2\n15\n15\n" + // Día 2 -> Añadir tienda en casilla 15 con 15 tenges
            "2\n40\n50\n" + // Día 3 -> Añadir tienda en casilla 40 con 50 tenges
            "1\n50\n" + // Día 4 -> Añadir robot en casilla 50
            "2\n80\n20\n" + // Día 5 -> Añadir tienda en casilla 80 con 20 tenges
            "2\n70\n30\n";  // Día 6 -> Añadir tienda en casilla 70 con 30 tenges

        // Redirigimos System.in para que el programa lea estos datos como si fueran tecleados
        ByteArrayInputStream testInput = new ByteArrayInputStream(inputData.getBytes());
        System.setIn(testInput);

        // Ejecutamos la simulación
        SilkRoad sim = new SilkRoad();
        sim.runSimulation();
    }
}