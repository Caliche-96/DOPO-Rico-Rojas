
/**
 * Write a description of class unittest here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Pruebas unitarias adaptadas al modelo actual de SilkRoad.
 * Validan cálculos de ganancias, movimientos y reabastecimiento.
 */
public class SilkRoadUnitTest {
    private SilkRoad silkRoad;

    @BeforeEach
    public void setup() {
        silkRoad = new SilkRoad(); // tablero 10x10
    }

    /**
     * Verifica que la ganancia total de un día sea correcta
     * cuando hay un robot y una tienda cercana.
     */
    @Test
    public void shouldCalculateDailyProfitCorrectly() {
        // Creamos un robot y una tienda
        int[] storeCoords = {15}; // número de casilla
        int[] robotCoords = {14};

        // Añadir robot y tienda usando métodos internos
        int[] rxy = silkRoad.spiralPath[robotCoords[0]];
        int[] sxy = silkRoad.spiralPath[storeCoords[0]];
        silkRoad.addRobot(rxy[0], rxy[1], robotCoords[0]);
        silkRoad.addStore(sxy[0], sxy[1], 20, storeCoords[0]);

        // Simulamos un día
        silkRoad.nextDay();

        // Debe haber ganancia positiva (20 - 1 = 19)
        assertTrue(silkRoad.profit() > 0, "La ganancia debe ser positiva");
    }

    /**
     * Verifica que las tiendas se vacíen y se pinten blancas
     * después de ser recolectadas por un robot.
     */
    @Test
    public void shouldEmptyStoreAndTurnWhiteAfterCollection() {
        int[] storeCoords = {10};
        int[] robotCoords = {9};

        int[] rxy = silkRoad.spiralPath[robotCoords[0]];
        int[] sxy = silkRoad.spiralPath[storeCoords[0]];
        silkRoad.addRobot(rxy[0], rxy[1], robotCoords[0]);
        silkRoad.addStore(sxy[0], sxy[1], 30, storeCoords[0]);

        silkRoad.nextDay();

        Store store = silkRoad.stores.get(0);
        assertEquals("white", store.getColor(), "La tienda debe quedar blanca al vaciarse");
        assertEquals(1, store.getTimesEmptied(), "El contador de vaciados debe incrementarse");
    }

    /**
     * Verifica que el robot registre sus ganancias correctamente
     * después de un movimiento exitoso.
     */
    @Test
    public void shouldTrackRobotProfitsCorrectly() {
        int[] storeCoords = {30};
        int[] robotCoords = {28};

        int[] rxy = silkRoad.spiralPath[robotCoords[0]];
        int[] sxy = silkRoad.spiralPath[storeCoords[0]];
        silkRoad.addRobot(rxy[0], rxy[1], robotCoords[0]);
        silkRoad.addStore(sxy[0], sxy[1], 50, storeCoords[0]);

        silkRoad.nextDay();

        Robot robot = silkRoad.robots.get(0);
        assertTrue(robot.getTotalProfit() > 0, "El robot debe haber ganado tenges");
        assertEquals(robot.getLastProfit(), robot.getTotalProfit(), "La ganancia total y la última deben coincidir tras un movimiento");
    }

    /**
     * Verifica que las tiendas se reabastezcan correctamente
     * al iniciar un nuevo día.
     */
    @Test
    public void shouldResupplyStoresAtStartOfDay() {
        int[] storeCoords = {5};
        int[] robotCoords = {4};

        int[] rxy = silkRoad.spiralPath[robotCoords[0]];
        int[] sxy = silkRoad.spiralPath[storeCoords[0]];
        silkRoad.addRobot(rxy[0], rxy[1], robotCoords[0]);
        silkRoad.addStore(sxy[0], sxy[1], 40, storeCoords[0]);

        silkRoad.nextDay();  // tienda vaciada
        silkRoad.nextDay();  // tienda reabastecida

        Store store = silkRoad.stores.get(0);
        assertNotEquals("white", store.getColor(), "La tienda debe recuperar su color original");
        assertEquals(40, store.getTenges(), "Debe reabastecerse con sus tenges originales");
    }
}
