package domain;


/**
 *  Nuestra clase  ClassRoyaleExceptions es una clase donde guardaremos todas las excepciones del proyecto 
 *
 * @author (Carlos Rojas-Eduardo Rico )
 * 
 */
public class ClashRoyaleException extends Exception
{
    public static String ELIXIR_UNKNOWN = "Elixir desconocido";
    public static String ELIXIR_ERROR = "El elixir está por fuera del rango establecido"; 
    public static String RESISTANCE_UNKNOWN= "Resistencia desconocida";
    public static String RESISTANCE_ERROR = "La resistencia está por fuera del rango establecido"; 
    public static String IMPOSSIBLE= "No es posible que un mazo no tenga cartas"; 
    
    public ClashRoyaleException(String message)
    {
        super (message);
    }
}
